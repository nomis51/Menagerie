﻿namespace Menagerie.Core.Enums
{
    /// <summary>
    /// WinAPI Window states
    /// </summary>
    public enum ShowWindowEnum
    {
        Show = 5,
    };
}