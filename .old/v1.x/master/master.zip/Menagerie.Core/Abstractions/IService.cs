﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Abstractions
{
    /// <summary>
    /// What define a Service in Menagerie
    /// </summary>
    public interface IService
    {
        void Start();
    }
}