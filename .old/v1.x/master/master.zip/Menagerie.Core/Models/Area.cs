﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models
{
    public class Area
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }
}