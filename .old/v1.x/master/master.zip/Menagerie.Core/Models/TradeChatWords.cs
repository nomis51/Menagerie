﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models
{
    public class TradeChatWords
    {
        public string Words { get; set; }
        public bool Highlighted { get; set; }
        public int Index { get; set; }
    }
}