﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models.PoeApi.Stash
{
    public class StashTabsResult
    {
        public List<StashTab> Tabs { get; set; }
    }
}