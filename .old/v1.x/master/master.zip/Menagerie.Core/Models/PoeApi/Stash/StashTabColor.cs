﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models.PoeApi.Stash
{
    public abstract class StashTabColor
    {
        public int R { get; set; }
        public int G { get; set; }
        public int B { get; set; }
    }
}