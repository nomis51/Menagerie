﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models
{
    public class TradeRequestQueryStatus
    {
        public string Option { get; set; } = "online";
    }
}