﻿namespace Menagerie.Core.Models
{
    public abstract class TypeFiltersCategory
    {
        public string Option { get; set; }
    }
}