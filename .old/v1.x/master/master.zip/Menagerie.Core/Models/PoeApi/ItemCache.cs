﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models.PoeApi
{
    public class ItemCache
    {
        public PriceCheckResult Items { get; set; }
    }
}