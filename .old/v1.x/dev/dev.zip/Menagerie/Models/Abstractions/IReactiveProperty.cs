﻿namespace Menagerie.Models.Abstractions
{
    public interface IReactiveProperty
    {
        public void Notify();
    }
}