using System.Windows;

namespace Menagerie.Models
{
    public class ChaosRecipeItem
    {
        public Visibility Visibility { get; set; }
        public string ImageFilePath { get; set; }
        public int Count { get; set; }
    }
}