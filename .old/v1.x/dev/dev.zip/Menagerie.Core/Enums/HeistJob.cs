﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Enums {
    public enum HeistJob {
        Lockpicking,
        Counter_Thaumaturgy,
        Perception,
        Deception,
        Agility,
        Engineering,
        TrapDisarmament,
        Demolition,
        BruteForce
    }
}
