﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Enums {
    public enum ItemAltQuality {
        Anomalous,
        Divergent,
        Phantasmal,
        Superior,
        None
    }
}
