﻿namespace Menagerie.Core.Enums {
    public enum ItemVeiled {
        Prefix,
        Suffix,
        PrefixAndSuffix,
        None
    }
}
