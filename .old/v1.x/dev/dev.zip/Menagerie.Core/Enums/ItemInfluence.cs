﻿namespace Menagerie.Core.Enums {
    public enum ItemInfluence {
        Crusader,
        Elder,
        Hunter,
        Redeemer,
        Shaper,
        Warlord
    }
}
