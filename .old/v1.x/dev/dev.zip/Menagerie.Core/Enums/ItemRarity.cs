﻿namespace Menagerie.Core.Enums {
    public enum ItemRarity {
        Normal,
        Magic,
        Rare,
        Unique,
        Gem,
        DivinationCard,
        Currency
    }
}
