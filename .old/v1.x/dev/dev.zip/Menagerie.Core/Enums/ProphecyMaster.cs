﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Enums {
    public enum ProphecyMaster {
        Alva,
        Einhar,
        Niko,
        Jun,
        Zana,
        None
    }
}
