﻿namespace Menagerie.Core.Enums {
    public enum ItemModifierType {
        Pseudo,
        Explicit,
        Implicit,
        Crafted,
        Enchant,
        None
    }
}
