namespace Menagerie.Core.Services.Parsing.Abstractions
{
    public interface IService
    {
    }
}