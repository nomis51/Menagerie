﻿using System.Collections.Generic;

namespace Menagerie.Core.Models.PoeNinja
{
    public class PoeNinjaSparkLine
    {
        public double TotalChange { get; set; }
        public List<double?> Data { get; set; }
    }
}