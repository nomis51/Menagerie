namespace Menagerie.Core.Models.ItemsScan
{
    public class TradeWindowItem
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int StackSize { get; set; }
    }
}