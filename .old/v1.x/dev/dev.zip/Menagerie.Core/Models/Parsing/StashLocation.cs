namespace Menagerie.Core.Models.Parsing
{
    public class StashLocation
    {
        public string StashTab { get; set; }
        public int Left { get; set; }
        public int Top { get; set; }
    }
}