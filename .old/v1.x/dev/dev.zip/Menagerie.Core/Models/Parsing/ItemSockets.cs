﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models {
    public class ItemSockets {
        public int NbLinked { get; set; } = 0;
        public int NbWhite { get; set; } = 0;
    }
}
