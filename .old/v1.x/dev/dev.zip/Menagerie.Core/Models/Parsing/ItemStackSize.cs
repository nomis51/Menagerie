﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models {
    public class ItemStackSize {
        public int Value { get; set; }
        public int Max { get; set; }
    }
}
