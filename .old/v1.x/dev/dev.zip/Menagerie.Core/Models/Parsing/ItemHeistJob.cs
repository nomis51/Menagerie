﻿using Menagerie.Core.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models {
    public class ItemHeistJob {
        public HeistJob Name { get; set; }
        public int Level { get; set; }
    }
}
