﻿namespace Menagerie.Core.Models
{
    public class TypeFiltersRarity
    {
        public string Option { get; set; } = "unique";
    }
}