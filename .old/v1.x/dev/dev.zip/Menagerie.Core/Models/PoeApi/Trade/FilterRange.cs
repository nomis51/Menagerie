﻿namespace Menagerie.Core.Models
{
    public abstract class FilterRange
    {
        public double Min { get; set; }
        public double Max { get; set; }
    }
}