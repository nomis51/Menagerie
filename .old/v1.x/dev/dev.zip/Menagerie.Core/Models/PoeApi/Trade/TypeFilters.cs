﻿namespace Menagerie.Core.Models
{
    public class TypeFilters
    {
        public TypeFiltersRarity Rarity { get; set; }
        public TypeFiltersCategory Category { get; set; }
    }
}