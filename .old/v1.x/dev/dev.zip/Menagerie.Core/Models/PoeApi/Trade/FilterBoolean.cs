﻿namespace Menagerie.Core.Models
{
    public abstract class FilterBoolean
    {
        public bool Option { get; set; }
    }
}