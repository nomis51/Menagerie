﻿namespace Menagerie.Core.Models
{
    public abstract class StatFilterValue
    {
        public double Min { get; set; }
        public double Max { get; set; }
        public string Option { get; set; }
    }
}