﻿using System;
using System.Collections.Generic;
using System.Text;
using Menagerie.Core.Models.PoeApi.Price;

namespace Menagerie.Core.Models.PoeApi
{
    public class ItemCache
    {
        public PriceCheckResult Items { get; set; }
    }
}