﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models
{
    public abstract class FetchResultAccountStatus
    {
        public string League { get; set; }
    }
}