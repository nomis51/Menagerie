﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models
{
    public class TradeFiltersAccount
    {
        public string Input { get; set; }
    }
}