﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menagerie.Core.Models
{
    public class AlternateQualityGemFilter
    {
        public int Option { get; set; }
    }
}