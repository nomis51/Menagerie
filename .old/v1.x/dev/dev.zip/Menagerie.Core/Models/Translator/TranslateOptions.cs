﻿namespace Menagerie.Core.Models.Translator
{
    public class TranslateOptions
    {
        public string From { get; set; }
        public string To { get; set; }
        public string Tld { get; set; }
    }
}